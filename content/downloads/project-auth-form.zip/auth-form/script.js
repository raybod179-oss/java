const form = document.getElementById("form");
const msg = document.getElementById("msg");
const nameBox = document.getElementById("name-box");
const pass = document.getElementById("pass");
const go = document.getElementById("go");
let mode = "login";                                   // login | register

function setMode(m) {
  mode = m;
  document.getElementById("tab-login").classList.toggle("on", m === "login");
  document.getElementById("tab-register").classList.toggle("on", m === "register");
  nameBox.hidden = m === "login";
  go.textContent = m === "login" ? "ورود" : "ساخت حساب";
  pass.autocomplete = m === "login" ? "current-password" : "new-password";
  show("", "");
}
function show(text, type) { msg.textContent = text; msg.className = "msg " + type; }

document.getElementById("tab-login").addEventListener("click", () => setMode("login"));
document.getElementById("tab-register").addEventListener("click", () => setMode("register"));
document.getElementById("eye").addEventListener("click", (e) => {
  const hidden = pass.type === "password";
  pass.type = hidden ? "text" : "password";
  e.target.textContent = hidden ? "پنهان" : "نمایش";
});

form.addEventListener("submit", (e) => {
  e.preventDefault();                                  // جلوی رفرش صفحه
  const data = Object.fromEntries(new FormData(form)); // همه‌ی فیلدها در یک آبجکت
  if (mode === "register" && !data.name.trim()) return show("نام را وارد کن", "err");
  if (!data.email.includes("@")) return show("ایمیل معتبر نیست", "err");
  if (data.pass.length < 6) return show("رمز حداقل ۶ کاراکتر باشد", "err");
  show(mode === "login" ? "ورود موفق بود ✓" : "حساب ساخته شد ✓", "ok");
});
