const API = "https://api.tvmaze.com/search/shows?q=";
const grid = document.getElementById("grid");
const state = document.getElementById("state");
const detail = document.getElementById("detail");
let controller = null;            // برای لغو درخواست قبلی
let timer = null;

function setState(text, error = false) {
  state.textContent = text;
  state.className = "state" + (error ? " err" : "");
}
// متن خلاصه‌ی داستان HTML دارد؛ فقط متن خالصش را می‌گیریم
const plain = (html) => new DOMParser().parseFromString(html || "", "text/html").body.textContent;

async function search(text) {
  if (controller) controller.abort();               // درخواست قبلی بی‌فایده است
  controller = new AbortController();
  grid.innerHTML = ""; detail.hidden = true;
  if (!text) return setState("نام یک فیلم یا سریال را (انگلیسی) بنویس");
  setState("در حال جستجو…");
  try {
    const res = await fetch(API + encodeURIComponent(text), { signal: controller.signal });
    if (!res.ok) throw new Error("خطای سرور " + res.status);
    const results = await res.json();
    if (!results.length) return setState("چیزی پیدا نشد 😕");
    setState("");
    results.slice(0, 12).forEach(({ show }) => grid.append(card(show)));
  } catch (err) {
    if (err.name === "AbortError") return;           // لغو عمدی، خطا نیست
    setState("خطا: " + err.message, true);
  }
}

function card(show) {
  const c = document.createElement("div");
  c.className = "card";
  const img = document.createElement("img");
  img.alt = show.name; img.loading = "lazy";
  img.src = show.image ? show.image.medium : "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2' height='3'/>";
  const info = document.createElement("div");
  const year = show.premiered ? show.premiered.slice(0, 4) : "—";
  const rate = show.rating && show.rating.average ? "★ " + show.rating.average : "";
  info.innerHTML = "<b></b><br><small></small> <span class='rate'></span>";
  info.querySelector("b").textContent = show.name;
  info.querySelector("small").textContent = year;
  info.querySelector(".rate").textContent = rate;
  c.append(img, info);
  c.addEventListener("click", () => {
    detail.hidden = false;
    detail.innerHTML = "<h2></h2><p></p>";
    detail.querySelector("h2").textContent = show.name + " (" + year + ")";
    detail.querySelector("p").textContent = plain(show.summary) || "خلاصه‌ای ثبت نشده.";
  });
  return c;
}

document.getElementById("q").addEventListener("input", (e) => {
  clearTimeout(timer);                               // debounce: ۴۰۰ میلی‌ثانیه بعد از آخرین حرف
  timer = setTimeout(() => search(e.target.value.trim()), 400);
});
