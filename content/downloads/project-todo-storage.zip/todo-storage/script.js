const KEY = "todos-v1";
const list = document.getElementById("list");
const empty = document.getElementById("empty");
let todos = load();                // [{ id, text, done }]
let filter = "all";

function load() {
  try { return JSON.parse(localStorage.getItem(KEY)) || []; } catch (e) { return []; }
}
function save() {
  try { localStorage.setItem(KEY, JSON.stringify(todos)); } catch (e) {}
}

function visible() {
  if (filter === "active") return todos.filter((t) => !t.done);
  if (filter === "done") return todos.filter((t) => t.done);
  return todos;
}

function render() {
  list.innerHTML = "";
  visible().forEach((t) => {
    const li = document.createElement("li");
    li.dataset.id = t.id;
    li.className = t.done ? "done" : "";
    li.innerHTML = '<input type="checkbox" aria-label="انجام شد"><span></span><button data-act="del">حذف</button>';
    li.querySelector("input").checked = t.done;
    li.querySelector("span").textContent = t.text;
    list.append(li);
  });
  empty.hidden = visible().length > 0;
  const left = todos.filter((t) => !t.done).length;
  document.getElementById("left").textContent = left.toLocaleString("fa-IR") + " کار باقی مانده";
  document.querySelectorAll("#filters button").forEach((b) => b.classList.toggle("on", b.dataset.f === filter));
}
function commit() { save(); render(); }          // هر تغییر: ذخیره و دوباره رسم

document.getElementById("add").addEventListener("submit", (e) => {
  e.preventDefault();
  const input = document.getElementById("text");
  const text = input.value.trim();
  if (!text) return;
  todos.push({ id: Date.now(), text, done: false });
  input.value = "";
  commit();
});

// Event Delegation: یک شنونده برای همه‌ی آیتم‌ها
list.addEventListener("click", (e) => {
  const li = e.target.closest("li");
  if (!li) return;
  const id = Number(li.dataset.id);
  if (e.target.dataset.act === "del") todos = todos.filter((t) => t.id !== id);
  else if (e.target.type === "checkbox") todos = todos.map((t) => (t.id === id ? { ...t, done: !t.done } : t));
  else return;
  commit();
});
list.addEventListener("dblclick", (e) => {                 // ویرایش با دابل‌کلیک
  const li = e.target.closest("li");
  if (!li || e.target.tagName !== "SPAN") return;
  const id = Number(li.dataset.id);
  const next = prompt("ویرایش:", e.target.textContent);
  if (next && next.trim()) { todos = todos.map((t) => (t.id === id ? { ...t, text: next.trim() } : t)); commit(); }
});
document.getElementById("filters").addEventListener("click", (e) => {
  if (e.target.dataset.f) { filter = e.target.dataset.f; render(); }
});
document.getElementById("clear").addEventListener("click", () => { todos = todos.filter((t) => !t.done); commit(); });
render();
