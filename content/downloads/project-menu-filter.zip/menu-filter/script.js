const MENU = [
  { name: "کباب کوبیده", cat: "غذای اصلی", price: 320000, veg: false },
  { name: "جوجه کباب", cat: "غذای اصلی", price: 290000, veg: false },
  { name: "قیمه بادمجان", cat: "غذای اصلی", price: 210000, veg: false },
  { name: "کوکو سبزی", cat: "غذای اصلی", price: 150000, veg: true },
  { name: "سالاد شیرازی", cat: "پیش‌غذا", price: 60000, veg: true },
  { name: "ماست و خیار", cat: "پیش‌غذا", price: 45000, veg: true },
  { name: "سوپ جو", cat: "پیش‌غذا", price: 70000, veg: false },
  { name: "دوغ محلی", cat: "نوشیدنی", price: 30000, veg: true },
  { name: "چای زعفرانی", cat: "نوشیدنی", price: 25000, veg: true },
  { name: "بستنی سنتی", cat: "دسر", price: 80000, veg: true },
];
const state = { text: "", cat: "همه", veg: false, sort: "" };     // همه‌ی فیلترها در یک آبجکت

const list = document.getElementById("list");
const chips = document.getElementById("chips");

["همه", ...new Set(MENU.map((m) => m.cat))].forEach((c) => {
  const b = document.createElement("button");
  b.textContent = c;
  b.dataset.cat = c;
  chips.append(b);
});

// نوشتن متن با کلمه‌ی پررنگ‌شده، بدون innerHTML (امن)
function highlight(el, text, query) {
  el.textContent = "";
  const i = query ? text.indexOf(query) : -1;
  if (i === -1) return (el.textContent = text);
  el.append(text.slice(0, i));
  const m = document.createElement("mark");
  m.textContent = text.slice(i, i + query.length);
  el.append(m, text.slice(i + query.length));
}

function render() {
  let items = MENU.filter((m) =>
    m.name.includes(state.text) &&
    (state.cat === "همه" || m.cat === state.cat) &&
    (!state.veg || m.veg));
  if (state.sort) items = items.toSorted((a, b) => (state.sort === "asc" ? a.price - b.price : b.price - a.price));
  list.innerHTML = "";
  items.forEach((m) => {
    const row = document.createElement("div");
    row.className = "dish";
    row.innerHTML = "<div><b></b><small></small></div><span class='price'></span>";
    highlight(row.querySelector("b"), m.name, state.text);
    row.querySelector("small").textContent = m.cat + (m.veg ? " · 🌱" : "");
    row.querySelector(".price").textContent = m.price.toLocaleString("fa-IR") + " تومان";
    list.append(row);
  });
  document.getElementById("count").textContent = items.length.toLocaleString("fa-IR") + " مورد";
  document.getElementById("empty").hidden = items.length > 0;
  chips.querySelectorAll("button").forEach((b) => b.classList.toggle("on", b.dataset.cat === state.cat));
}

document.getElementById("q").addEventListener("input", (e) => { state.text = e.target.value.trim(); render(); });
document.getElementById("sort").addEventListener("change", (e) => { state.sort = e.target.value; render(); });
document.getElementById("veg").addEventListener("change", (e) => { state.veg = e.target.checked; render(); });
chips.addEventListener("click", (e) => { if (e.target.dataset.cat) { state.cat = e.target.dataset.cat; render(); } });
render();
