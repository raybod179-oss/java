const API = "https://jsonplaceholder.typicode.com/posts";
const PER_PAGE = 5;
const list = document.getElementById("list");
const state = document.getElementById("state");
const detail = document.getElementById("detail");
let page = 1;

function setState(text, isError = false, retry = false) {
  state.textContent = text;
  state.className = "state" + (isError ? " err" : "");
  if (retry) {
    const b = document.createElement("button");
    b.textContent = "تلاش دوباره";
    b.addEventListener("click", () => load());
    state.append(" ", b);
  }
}

async function getJSON(url) {
  const res = await fetch(url);
  if (!res.ok) throw new Error("خطای سرور " + res.status);
  return res.json();
}

async function load() {
  setState("در حال دریافت…");
  list.innerHTML = "";
  try {
    const posts = await getJSON(API + "?_page=" + page + "&_limit=" + PER_PAGE);
    posts.forEach((p) => {
      const card = document.createElement("div");
      card.className = "post";
      card.innerHTML = "<h3></h3><p></p>";
      card.querySelector("h3").textContent = p.title;
      card.querySelector("p").textContent = p.body.slice(0, 70) + "…";
      card.addEventListener("click", () => open(p.id));
      list.append(card);
    });
    setState("");
    document.getElementById("page").textContent = "صفحه " + page;
    document.getElementById("prev").disabled = page === 1;
  } catch (err) {
    setState("دریافت نشد: " + err.message, true, true);
  }
}

async function open(id) {
  detail.hidden = false;
  detail.textContent = "در حال دریافت…";
  try {
    const p = await getJSON(API + "/" + id);
    detail.textContent = "";
    const h = document.createElement("b"); h.textContent = p.title;
    const t = document.createElement("p"); t.textContent = p.body;
    detail.append(h, t);
  } catch (err) {
    detail.textContent = "خطا: " + err.message;
  }
}

document.getElementById("next").addEventListener("click", () => { page++; load(); });
document.getElementById("prev").addEventListener("click", () => { if (page > 1) { page--; load(); } });
load();
