// در پروژه‌ی واقعی این داده در فایل products.json است و با fetch("products.json") خوانده می‌شود.
// اینجا آن را با Blob شبیه‌سازی می‌کنیم تا همین‌جا هم بدون سرور کار کند.
const DATA = [
  { id: 1, name: "کیبورد مکانیکی", cat: "لوازم", price: 1800000 },
  { id: 2, name: "ماوس بی‌سیم", cat: "لوازم", price: 650000 },
  { id: 3, name: "کتاب جاوااسکریپت", cat: "کتاب", price: 240000 },
  { id: 4, name: "کتاب طراحی وب", cat: "کتاب", price: 310000 },
  { id: 5, name: "پایه‌ی لپ‌تاپ", cat: "لوازم", price: 420000 },
];
const url = URL.createObjectURL(new Blob([JSON.stringify(DATA)], { type: "application/json" }));

const list = document.getElementById("list");
const state = document.getElementById("state");
const q = document.getElementById("q");
const cat = document.getElementById("cat");
let products = [];

async function load() {
  try {
    const res = await fetch(url);
    if (!res.ok) throw new Error("HTTP " + res.status);
    products = await res.json();
    [...new Set(products.map((p) => p.cat))].forEach((c) => cat.append(new Option(c, c)));
    render();
  } catch (err) {
    state.textContent = "خطا در دریافت داده: " + err.message;
  }
}

function render() {
  const text = q.value.trim();
  const shown = products.filter((p) => p.name.includes(text) && (!cat.value || p.cat === cat.value));
  list.innerHTML = "";
  shown.forEach((p) => {
    const row = document.createElement("div");
    row.className = "item";
    row.innerHTML = "<div><b></b><br><small></small></div><span class='price'></span>";
    row.querySelector("b").textContent = p.name;                 // textContent: امن در برابر XSS
    row.querySelector("small").textContent = p.cat;
    row.querySelector(".price").textContent = p.price.toLocaleString("fa-IR") + " تومان";
    list.append(row);
  });
  state.textContent = shown.length ? "" : "موردی پیدا نشد";
}

q.addEventListener("input", render);
cat.addEventListener("change", render);
load();
