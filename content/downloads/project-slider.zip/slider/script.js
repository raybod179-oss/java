const slider = document.getElementById("slider");
const track = document.getElementById("track");
const dotsBox = document.getElementById("dots");
const slides = track.children;
let index = 0;
let timer = null;

// ساخت نقطه‌ها از روی تعداد اسلایدها
[...slides].forEach((_, i) => {
  const dot = document.createElement("button");
  dot.className = "dot";
  dot.setAttribute("aria-label", "اسلاید " + (i + 1));
  dot.addEventListener("click", () => goTo(i));
  dotsBox.append(dot);
});

function goTo(i) {
  index = (i + slides.length) % slides.length;       // چرخش بی‌نهایت
  track.style.transform = "translateX(" + index * 100 + "%)";   // در صفحه‌ی راست‌چین مثبت است
  [...dotsBox.children].forEach((d, n) => d.classList.toggle("active", n === index));
}
const next = () => goTo(index + 1);
const prev = () => goTo(index - 1);

function play() { stop(); timer = setInterval(next, 4000); }
function stop() { clearInterval(timer); }

document.getElementById("next").addEventListener("click", next);
document.getElementById("prev").addEventListener("click", prev);
slider.addEventListener("mouseenter", stop);          // موس روی اسلایدر: توقف
slider.addEventListener("mouseleave", play);
document.addEventListener("keydown", (e) => {
  if (e.key === "ArrowLeft") next();                  // راست‌چین: چپ یعنی بعدی
  if (e.key === "ArrowRight") prev();
});

// کشیدن با انگشت
let startX = 0;
slider.addEventListener("touchstart", (e) => { startX = e.touches[0].clientX; }, { passive: true });
slider.addEventListener("touchend", (e) => {
  const dx = e.changedTouches[0].clientX - startX;
  if (Math.abs(dx) > 40) (dx < 0 ? next : prev)();
});

goTo(0);
play();
