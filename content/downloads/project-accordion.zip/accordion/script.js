const items = [...document.querySelectorAll(".acc-item")];

function setOpen(item, open) {
  const button = item.querySelector(".acc-q");
  const panel = item.querySelector(".acc-a");
  button.setAttribute("aria-expanded", String(open));
  item.classList.toggle("open", open);
  panel.style.maxHeight = open ? panel.scrollHeight + "px" : "0px";
}

items.forEach((item) => {
  item.querySelector(".acc-q").addEventListener("click", () => {
    const wasOpen = item.classList.contains("open");
    items.forEach((other) => setOpen(other, false));   // همه را ببند
    if (!wasOpen) setOpen(item, true);                  // اگر بسته بود، این یکی را باز کن
  });
});

setOpen(items[0], true);                                // در شروع، اولی باز باشد
