const LIST = "https://picsum.photos/v2/list?limit=12&page=";
const thumb = (id) => "https://picsum.photos/id/" + id + "/360/" + (240 + (id % 4) * 60);
const full = (id) => "https://picsum.photos/id/" + id + "/1000/700";

const grid = document.getElementById("grid");
const sentinel = document.getElementById("sentinel");
let page = 1, loading = false, done = false;
const photos = [];                                    // همه‌ی تصاویر بارگیری‌شده
let current = 0;

let likes = new Set();
try { likes = new Set(JSON.parse(localStorage.getItem("likes")) || []); } catch (e) {}
const saveLikes = () => { try { localStorage.setItem("likes", JSON.stringify([...likes])); } catch (e) {} };

async function loadMore() {
  if (loading || done) return;
  loading = true;
  sentinel.textContent = "در حال بارگذاری…";
  try {
    const res = await fetch(LIST + page);
    if (!res.ok) throw new Error("HTTP " + res.status);
    const items = await res.json();
    if (!items.length) { done = true; sentinel.textContent = "پایان 🎉"; return; }
    items.forEach((it) => addPhoto(it));
    page++;
    sentinel.textContent = "";
  } catch (err) {
    sentinel.textContent = "خطا: " + err.message + " (برای تلاش دوباره اسکرول کن)";
  } finally {
    loading = false;
  }
}

function addPhoto(it) {
  const index = photos.push(it) - 1;
  const box = document.createElement("div");
  box.className = "item";
  const img = document.createElement("img");
  img.src = thumb(it.id); img.alt = "عکس از " + it.author; img.loading = "lazy";
  const heart = document.createElement("button");
  heart.textContent = "♥";
  heart.className = likes.has(it.id) ? "on" : "";
  heart.setAttribute("aria-label", "علاقه‌مندی");
  heart.addEventListener("click", (e) => {
    e.stopPropagation();                              // کلیک قلب، لایت‌باکس را باز نکند
    likes.has(it.id) ? likes.delete(it.id) : likes.add(it.id);
    heart.classList.toggle("on", likes.has(it.id));
    saveLikes();
  });
  box.append(img, heart);
  box.addEventListener("click", () => openBox(index));
  grid.append(box);
}

// اسکرول بی‌پایان: وقتی نشانگر انتهای لیست دیده شد، صفحه‌ی بعد
if ("IntersectionObserver" in window) {
  new IntersectionObserver((entries) => { if (entries[0].isIntersecting) loadMore(); }, { rootMargin: "200px" }).observe(sentinel);
} else loadMore();

// لایت‌باکس
const box = document.getElementById("box");
function openBox(i) {
  current = (i + photos.length) % photos.length;
  document.getElementById("big").src = full(photos[current].id);
  document.getElementById("cap").textContent = "عکس از " + photos[current].author;
  box.classList.add("open");
}
document.getElementById("x").addEventListener("click", () => box.classList.remove("open"));
document.getElementById("n").addEventListener("click", () => openBox(current + 1));
document.getElementById("p").addEventListener("click", () => openBox(current - 1));
document.addEventListener("keydown", (e) => {
  if (!box.classList.contains("open")) return;
  if (e.key === "Escape") box.classList.remove("open");
  if (e.key === "ArrowLeft") openBox(current + 1);
  if (e.key === "ArrowRight") openBox(current - 1);
});
