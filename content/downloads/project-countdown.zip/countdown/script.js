// مقصد: شروع روز اول سال نو (نیمه‌شب به وقت تهران)
const TARGETS = {
  nowruz: { label: "۱ فروردین ۱۴۰۶", date: new Date("2027-03-21T00:00:00+03:30") },
  gregorian: { label: "۱ ژانویه ۲۰۲۷", date: new Date("2027-01-01T00:00:00+03:30") },
};

const select = document.getElementById("which");
const boxes = document.getElementById("boxes");
const done = document.getElementById("done");
const el = (id) => document.getElementById(id);

const fa = (n) => String(n).padStart(2, "0").replace(/\d/g, (d) => "۰۱۲۳۴۵۶۷۸۹"[d]);

function tick() {
  const target = TARGETS[select.value];
  el("target").textContent = "تا " + target.label;
  const diff = target.date - Date.now();            // اختلاف به میلی‌ثانیه
  if (diff <= 0) {
    boxes.hidden = true;
    done.hidden = false;
    return;
  }
  boxes.hidden = false;
  done.hidden = true;
  const total = Math.floor(diff / 1000);
  el("d").textContent = fa(Math.floor(total / 86400));
  el("h").textContent = fa(Math.floor((total % 86400) / 3600));
  el("m").textContent = fa(Math.floor((total % 3600) / 60));
  el("s").textContent = fa(total % 60);
}

select.addEventListener("change", tick);
setInterval(tick, 1000);
tick();
