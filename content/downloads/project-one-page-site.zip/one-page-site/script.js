// ۱) منوی موبایل
const links = document.getElementById("links");
const burger = document.getElementById("burger");
burger.addEventListener("click", () => {
  const open = links.classList.toggle("open");
  burger.setAttribute("aria-expanded", String(open));
});
links.addEventListener("click", () => links.classList.remove("open"));

// ۲) افکت تایپ
const words = ["سایت می‌سازیم", "فروشگاه می‌سازیم", "ایده را اجرا می‌کنیم"];
const typed = document.getElementById("typed");
let w = 0, c = 0, deleting = false;
function type() {
  const word = words[w];
  c += deleting ? -1 : 1;
  typed.textContent = word.slice(0, c);
  let delay = deleting ? 40 : 90;
  if (!deleting && c === word.length) { deleting = true; delay = 1200; }
  else if (deleting && c === 0) { deleting = false; w = (w + 1) % words.length; delay = 300; }
  setTimeout(type, delay);
}
type();

// ۳) ظاهر شدن کارت‌ها و شمارنده با اسکرول
function countUp(el) {
  const to = Number(el.dataset.to);
  let n = 0;
  const step = () => { n += Math.ceil(to / 40); el.textContent = Math.min(n, to); if (n < to) requestAnimationFrame(step); };
  step();
}
if ("IntersectionObserver" in window) {
  const io = new IntersectionObserver((entries) => {
    entries.forEach((e) => {
      if (!e.isIntersecting) return;
      e.target.classList.add("in");
      if (e.target.dataset.to) countUp(e.target);
      io.unobserve(e.target);                        // فقط یک بار
    });
  }, { threshold: 0.3 });
  document.querySelectorAll(".card, [data-to]").forEach((el) => io.observe(el));
} else {
  document.querySelectorAll(".card").forEach((el) => el.classList.add("in"));
}

// ۴) فرم تماس
document.getElementById("form").addEventListener("submit", (e) => {
  e.preventDefault();
  const err = document.getElementById("err");
  const name = document.getElementById("name").value.trim();
  const email = document.getElementById("email").value.trim();
  const msg = document.getElementById("msg").value.trim();
  err.className = "err";
  if (name.length < 2) return (err.textContent = "نام را وارد کن");
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return (err.textContent = "ایمیل معتبر نیست");
  if (msg.length < 10) return (err.textContent = "پیام حداقل ۱۰ کاراکتر باشد");
  err.className = "err ok";
  err.textContent = "پیام شما ثبت شد ✓";
  e.target.reset();
});

// ۵) برگشت به بالا
const toTop = document.getElementById("top");
window.addEventListener("scroll", () => toTop.classList.toggle("show", window.scrollY > 300), { passive: true });
toTop.addEventListener("click", () => window.scrollTo({ top: 0, behavior: "smooth" }));
