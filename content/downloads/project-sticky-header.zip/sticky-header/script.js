const header = document.getElementById("top");
const links = [...document.querySelectorAll("#nav a")];
const sections = links.map((a) => document.querySelector(a.getAttribute("href")));

// ۱) سایه‌ی هدر بعد از کمی اسکرول
function onScroll() {
  header.classList.toggle("scrolled", window.scrollY > 10);
}
window.addEventListener("scroll", onScroll, { passive: true });
onScroll();

// ۲) پررنگ کردن لینکِ بخش دیده‌شده
function setActive(id) {
  links.forEach((a) => a.classList.toggle("active", a.getAttribute("href") === "#" + id));
}
if ("IntersectionObserver" in window) {
  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) setActive(entry.target.id);
    });
  }, { rootMargin: "-40% 0px -55% 0px" });      // بخشی که وسط صفحه است
  sections.forEach((s) => observer.observe(s));
}
setActive("home");
