const RATE = 8000;
const TRACKS = [
  { title: "صبح بخیر", artist: "Rayvo", notes: [262, 294, 330, 392, 330, 294, 262, 196, 262, 330, 392, 523, 392, 330, 294, 262] },
  { title: "ساعت پنج", artist: "Rayvo", notes: [330, 392, 440, 392, 330, 294, 330, 262, 330, 392, 494, 440, 392, 330, 294, 262] },
  { title: "شب آرام", artist: "Rayvo", notes: [196, 247, 294, 247, 196, 220, 262, 220, 196, 247, 330, 294, 247, 220, 196, 147] },
];

// ساخت یک فایل WAV ساده در حافظه از روی نت‌ها (موج سینوسی)
function makeWav(notes, noteSec = 0.5) {
  const n = Math.floor(RATE * noteSec), total = n * notes.length;
  const buf = new ArrayBuffer(44 + total * 2), v = new DataView(buf);
  const str = (o, s) => [...s].forEach((c, i) => v.setUint8(o + i, c.charCodeAt(0)));
  str(0, "RIFF"); v.setUint32(4, 36 + total * 2, true); str(8, "WAVE"); str(12, "fmt ");
  v.setUint32(16, 16, true); v.setUint16(20, 1, true); v.setUint16(22, 1, true);
  v.setUint32(24, RATE, true); v.setUint32(28, RATE * 2, true); v.setUint16(32, 2, true); v.setUint16(34, 16, true);
  str(36, "data"); v.setUint32(40, total * 2, true);
  notes.forEach((f, k) => {
    for (let i = 0; i < n; i++) {
      const env = Math.min(1, i / 300, (n - i) / 600);                 // نرم شدن ابتدا و انتهای هر نت
      v.setInt16(44 + (k * n + i) * 2, Math.sin(2 * Math.PI * f * i / RATE) * 0.35 * env * 32767, true);
    }
  });
  return URL.createObjectURL(new Blob([buf], { type: "audio/wav" }));
}
TRACKS.forEach((t) => (t.src = makeWav(t.notes)));

const audio = new Audio();
const $ = (id) => document.getElementById(id);
const fmt = (s) => Math.floor(s / 60) + ":" + String(Math.floor(s % 60)).padStart(2, "0");
let index = 0;

function load(i, autoplay = false) {
  index = (i + TRACKS.length) % TRACKS.length;
  const t = TRACKS[index];
  audio.src = t.src;
  $("title").textContent = t.title;
  $("artist").textContent = t.artist;
  [...$("list").children].forEach((li, n) => li.classList.toggle("on", n === index));
  $("seek").value = 0; $("cur").textContent = "0:00";
  if (autoplay) audio.play();
}
function toggle() { audio.paused ? audio.play() : audio.pause(); }

TRACKS.forEach((t, i) => {
  const li = document.createElement("li");
  li.innerHTML = "<span></span><small></small>";
  li.firstChild.textContent = t.title;
  li.lastChild.textContent = t.artist;
  li.addEventListener("click", () => load(i, true));
  $("list").append(li);
});

audio.addEventListener("play", () => { $("play").textContent = "⏸"; $("cover").classList.add("play"); });
audio.addEventListener("pause", () => { $("play").textContent = "▶"; $("cover").classList.remove("play"); });
audio.addEventListener("loadedmetadata", () => { $("dur").textContent = fmt(audio.duration); });
audio.addEventListener("timeupdate", () => {
  if (!audio.duration) return;
  $("seek").value = (audio.currentTime / audio.duration) * 100;
  $("cur").textContent = fmt(audio.currentTime);
});
audio.addEventListener("ended", () => load(index + 1, true));     // آهنگ بعدی خودکار

$("play").addEventListener("click", toggle);
$("next").addEventListener("click", () => load(index + 1, !audio.paused));
$("prev").addEventListener("click", () => load(index - 1, !audio.paused));
$("seek").addEventListener("input", (e) => { if (audio.duration) audio.currentTime = (e.target.value / 100) * audio.duration; });
$("vol").addEventListener("input", (e) => { audio.volume = Number(e.target.value); });
audio.volume = 0.7;
load(0);
