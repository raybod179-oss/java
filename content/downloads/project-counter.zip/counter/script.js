const valueEl = document.getElementById("value");
const stepEl = document.getElementById("step");
let count = 0;                       // تنها منبع حقیقت (state)

function render() {
  valueEl.textContent = count.toLocaleString("fa-IR");
  valueEl.className = "value " + (count > 0 ? "pos" : count < 0 ? "neg" : "");
}
function change(direction) {
  count += direction * Number(stepEl.value);
  render();
}
function reset() { count = 0; render(); }

document.getElementById("inc").addEventListener("click", () => change(1));
document.getElementById("dec").addEventListener("click", () => change(-1));
document.getElementById("reset").addEventListener("click", reset);
document.addEventListener("keydown", (e) => {
  if (e.key === "ArrowUp") change(1);
  else if (e.key === "ArrowDown") change(-1);
  else if (e.key.toLowerCase() === "r") reset();
});
render();
