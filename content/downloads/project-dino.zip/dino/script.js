const game = document.getElementById("game");
const dino = document.getElementById("dino");
const cactus = document.getElementById("cactus");
const msg = document.getElementById("msg");
const scoreEl = document.getElementById("score");
const bestEl = document.getElementById("best");

const W = 560, GRAVITY = 0.7, JUMP = 13;
let y = 0, vy = 0;                  // ارتفاع دایناسور از زمین و سرعت عمودی
let cx = W + 100, speed = 6;        // موقعیت و سرعت مانع
let score = 0, best = 0, running = false;

try { best = Number(localStorage.getItem("dino-best")) || 0; } catch (e) {}
bestEl.textContent = best;

function jump() {
  if (!running) return start();
  if (y === 0) vy = JUMP;           // فقط روی زمین می‌شود پرید
}
function start() {
  y = 0; vy = 0; cx = W + 100; speed = 6; score = 0;
  scoreEl.textContent = 0;
  msg.hidden = true;
  running = true;
  requestAnimationFrame(loop);
}
function gameOver() {
  running = false;
  if (score > best) {
    best = score;
    bestEl.textContent = best;
    try { localStorage.setItem("dino-best", best); } catch (e) {}
  }
  msg.textContent = "باختی! امتیاز " + score + " (Space برای دوباره)";
  msg.hidden = false;
}

function update() {
  vy -= GRAVITY;                    // گرانش
  y = Math.max(0, y + vy);
  if (y === 0) vy = 0;
  cx -= speed;
  if (cx < -30) {                   // مانع از صفحه رفت: امتیاز و مانع جدید
    cx = W + Math.random() * 250;
    score++;
    scoreEl.textContent = score;
    speed = Math.min(speed + 0.25, 13);
  }
  const hit = cx < 74 && cx + 20 > 40 && y < 38;     // برخورد مستطیل‌ها
  if (hit) gameOver();
}
function render() {
  dino.style.bottom = 34 + y + "px";
  cactus.style.left = cx + "px";
}
function loop() {
  if (!running) return;
  update();
  render();
  requestAnimationFrame(loop);
}

document.addEventListener("keydown", (e) => {
  if (e.code === "Space" || e.key === "ArrowUp") { e.preventDefault(); jump(); }
});
game.addEventListener("pointerdown", jump);
