const form = document.getElementById("form");
const go = document.getElementById("go");

// هر قانون: تابعی که در صورت خطا متن خطا و در صورت درست بودن "" برمی‌گرداند
const rules = {
  name:  (v) => (v.trim().split(/\s+/).length >= 2 ? "" : "نام و نام خانوادگی را کامل بنویس"),
  email: (v) => (/^[\w.+-]+@[\w-]+\.[\w.-]+$/.test(v) ? "" : "ایمیل معتبر نیست"),
  phone: (v) => (/^09\d{9}$/.test(v) ? "" : "موبایل باید با 09 شروع شود و ۱۱ رقم باشد"),
  pass:  (v) => (v.length >= 8 && /\d/.test(v) && /[a-zA-Z]/.test(v) ? "" : "حداقل ۸ کاراکتر با حرف و عدد"),
  pass2: (v) => (v === form.elements.pass.value && v !== "" ? "" : "تکرار رمز یکسان نیست"),
};
const touched = new Set();                              // فقط فیلدهایی که کاربر لمس کرده

function check(name, showError = true) {
  const input = form.elements[name];
  const error = rules[name](input.value);
  if (showError) {
    const box = input.closest(".f");
    box.classList.toggle("bad", !!error);
    box.classList.toggle("good", !error);
    box.querySelector(".err").textContent = error;
  }
  return !error;
}
function refresh() {
  go.disabled = !Object.keys(rules).every((n) => check(n, touched.has(n)));
}

form.addEventListener("input", (e) => {
  touched.add(e.target.name);
  if (e.target.name === "pass") touched.has("pass2") && check("pass2");
  refresh();
});
form.addEventListener("submit", (e) => {
  e.preventDefault();
  if (Object.keys(rules).every((n) => check(n))) document.getElementById("ok").hidden = false;
});
