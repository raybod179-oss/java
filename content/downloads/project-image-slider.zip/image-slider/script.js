// تصاویر به‌صورت SVG تولید می‌شوند تا نیازی به فایل نباشد؛ در پروژه‌ی واقعی آدرس عکس‌ها را بگذار.
const colors = [["#f59e0b", "#7c2d12"], ["#22c55e", "#064e3b"], ["#3b82f6", "#1e1b4b"], ["#ec4899", "#4a044e"], ["#14b8a6", "#134e4a"]];
const names = ["غروب", "جنگل", "اقیانوس", "گل‌ها", "کوهستان"];
const svg = (a, b, n) => "data:image/svg+xml;utf8," + encodeURIComponent(
  '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 200"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1">' +
  '<stop offset="0" stop-color="' + a + '"/><stop offset="1" stop-color="' + b + '"/></linearGradient></defs>' +
  '<rect width="320" height="200" fill="url(#g)"/><circle cx="' + (60 + n * 50) + '" cy="70" r="34" fill="rgba(255,255,255,.25)"/></svg>');
const photos = colors.map(([a, b], i) => ({ src: svg(a, b, i), title: names[i] }));

const main = document.getElementById("main");
const cap = document.getElementById("cap");
const thumbs = document.getElementById("thumbs");
const count = document.getElementById("count");
let index = 0;

photos.forEach((p, i) => {
  const b = document.createElement("button");
  b.setAttribute("aria-label", "تصویر " + (i + 1));
  const im = document.createElement("img");
  im.src = p.src; im.alt = p.title; im.loading = "lazy";     // بارگذاری تنبل
  b.append(im);
  b.addEventListener("click", () => show(i));
  thumbs.append(b);
});

function show(i) {
  index = (i + photos.length) % photos.length;
  main.src = photos[index].src;
  main.alt = photos[index].title;
  cap.textContent = photos[index].title;
  count.textContent = (index + 1).toLocaleString("fa-IR") + " از " + photos.length.toLocaleString("fa-IR");
  [...thumbs.children].forEach((b, n) => b.classList.toggle("on", n === index));
  main.style.animation = "none"; void main.offsetWidth; main.style.animation = "";   // شروع دوباره‌ی انیمیشن
}

document.getElementById("next").addEventListener("click", () => show(index + 1));
document.getElementById("prev").addEventListener("click", () => show(index - 1));
document.getElementById("gallery").addEventListener("keydown", (e) => {
  if (e.key === "ArrowLeft") show(index + 1);
  if (e.key === "ArrowRight") show(index - 1);
});
// پیش‌بارگذاری تصویر بعدی تا لغزش فوری باشد
photos.forEach((p) => { const im = new Image(); im.src = p.src; });
show(0);
