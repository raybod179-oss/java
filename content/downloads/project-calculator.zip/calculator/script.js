// ماشین حالت: عدد فعلی (متن)، عدد قبلی، عملگر و اینکه تازه محاسبه شده یا نه
let cur = "0", prev = null, op = null, fresh = false;
const curEl = document.getElementById("cur");
const histEl = document.getElementById("hist");
const SYMBOL = { "+": "+", "-": "−", "*": "×", "/": "÷" };

function calc(a, b, o) {
  a = Number(a); b = Number(b);
  if (o === "+") return a + b;
  if (o === "-") return a - b;
  if (o === "*") return a * b;
  if (o === "/") return b === 0 ? null : a / b;       // تقسیم بر صفر
}
const clean = (n) => String(Math.round(n * 1e10) / 1e10);   // 0.1+0.2 → 0.3

function show() {
  curEl.textContent = cur;
  histEl.textContent = prev !== null && op ? prev + " " + SYMBOL[op] : "";
}
function error(msg) { cur = msg; prev = null; op = null; fresh = true; show(); }

function press(k) {
  if (cur === "تقسیم بر صفر") cur = "0";
  if (/^\d$/.test(k)) {
    cur = fresh || cur === "0" ? k : cur + k;
    fresh = false;
  } else if (k === ".") {
    if (fresh) { cur = "0."; fresh = false; }
    else if (!cur.includes(".")) cur += ".";
  } else if (k === "C") {
    cur = "0"; prev = null; op = null; fresh = false;
  } else if (k === "±") {
    if (cur !== "0") cur = cur.startsWith("-") ? cur.slice(1) : "-" + cur;
  } else if (k === "%") {
    cur = clean(Number(cur) / 100);
  } else if (k === "Backspace") {
    cur = cur.length > 1 && !fresh ? cur.slice(0, -1) : "0";
    if (cur === "-") cur = "0";
  } else if ("+-*/".includes(k)) {
    if (op && !fresh) {                               // زنجیره: 2 + 3 + ...
      const r = calc(prev, cur, op);
      if (r === null) return error("تقسیم بر صفر");
      prev = clean(r); cur = prev;
    } else prev = cur;
    op = k; fresh = true;
  } else if (k === "=" || k === "Enter") {
    if (!op) return;
    const r = calc(prev, cur, op);
    if (r === null) return error("تقسیم بر صفر");
    histEl.textContent = prev + " " + SYMBOL[op] + " " + cur + " =";
    cur = clean(r); prev = null; op = null; fresh = true;
    curEl.textContent = cur;
    return;
  }
  show();
}

document.getElementById("keys").addEventListener("click", (e) => { if (e.target.dataset.k) press(e.target.dataset.k); });
document.addEventListener("keydown", (e) => {
  if (/^[\d.+\-*\/%]$/.test(e.key) || ["Enter", "Backspace"].includes(e.key) || e.key === "=") {
    e.preventDefault();
    press(e.key === "=" ? "=" : e.key);
  } else if (e.key === "Escape") press("C");
});
show();
