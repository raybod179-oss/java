const root = document.documentElement;
const button = document.getElementById("toggle");

function getSaved() {
  try { return localStorage.getItem("theme"); } catch (e) { return null; }
}
function save(theme) {
  try { localStorage.setItem("theme", theme); } catch (e) { /* مرورگر اجازه نداد */ }
}

const prefersDark = window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches;
let theme = getSaved() || (prefersDark ? "dark" : "light");   // اول انتخاب خود کاربر، بعد سیستم

function apply(t) {
  root.setAttribute("data-theme", t);
  button.textContent = t === "dark" ? "☀️ روشن" : "🌙 تیره";
  button.setAttribute("aria-pressed", String(t === "dark"));
}

button.addEventListener("click", () => {
  theme = theme === "dark" ? "light" : "dark";
  apply(theme);
  save(theme);
});
apply(theme);
