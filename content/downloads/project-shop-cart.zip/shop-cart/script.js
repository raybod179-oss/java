const PRODUCTS = [
  { id: 1, name: "هدفون", emoji: "🎧", price: 950000 },
  { id: 2, name: "کتاب", emoji: "📘", price: 240000 },
  { id: 3, name: "ساعت", emoji: "⌚", price: 1400000 },
  { id: 4, name: "کوله‌پشتی", emoji: "🎒", price: 780000 },
  { id: 5, name: "لیوان", emoji: "☕", price: 90000 },
  { id: 6, name: "ماوس", emoji: "🖱️", price: 520000 },
];
const KEY = "cart-v1";
const money = (n) => n.toLocaleString("fa-IR") + " تومان";

// سبد: { شناسه: تعداد }
let cart = (() => { try { return JSON.parse(localStorage.getItem(KEY)) || {}; } catch (e) { return {}; } })();
const save = () => { try { localStorage.setItem(KEY, JSON.stringify(cart)); } catch (e) {} };

const grid = document.getElementById("grid");
PRODUCTS.forEach((p) => {
  const d = document.createElement("div");
  d.className = "prod";
  d.innerHTML = "<div class='em'></div><b></b><small></small><button>افزودن به سبد</button>";
  d.querySelector(".em").textContent = p.emoji;
  d.querySelector("b").textContent = p.name;
  d.querySelector("small").textContent = money(p.price);
  d.querySelector("button").addEventListener("click", () => change(p.id, 1));
  grid.append(d);
});

function change(id, delta) {
  cart[id] = (cart[id] || 0) + delta;
  if (cart[id] <= 0) delete cart[id];
  save();
  render();
}

function render() {
  const rows = document.getElementById("rows");
  rows.innerHTML = "";
  let total = 0, count = 0;
  Object.entries(cart).forEach(([id, qty]) => {
    const p = PRODUCTS.find((x) => x.id === Number(id));
    total += p.price * qty; count += qty;
    const r = document.createElement("div");
    r.className = "row";
    r.innerHTML = "<span></span><button data-d='-1'>−</button><b></b><button data-d='1'>+</button>";
    r.querySelector("span").textContent = p.emoji + " " + p.name;
    r.querySelector("b").textContent = qty.toLocaleString("fa-IR");
    r.querySelectorAll("button").forEach((b) => b.addEventListener("click", () => change(p.id, Number(b.dataset.d))));
    rows.append(r);
  });
  if (!count) rows.innerHTML = "<p class='muted'>سبد خالی است</p>";
  document.getElementById("total").textContent = money(total);
  document.getElementById("badge").textContent = count.toLocaleString("fa-IR");
}

const panel = document.getElementById("cart");
document.getElementById("open").addEventListener("click", () => panel.classList.add("open"));
document.getElementById("close").addEventListener("click", () => panel.classList.remove("open"));
document.getElementById("pay").addEventListener("click", () => {
  document.getElementById("msg").textContent = Object.keys(cart).length ? "سفارش ثبت شد (نمونه) ✓" : "اول محصولی اضافه کن";
  if (Object.keys(cart).length) { cart = {}; save(); render(); }
});
render();
