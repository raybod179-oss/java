let lastFocus = null;

function openModal(id) {
  const modal = document.getElementById(id);
  if (!modal) return;
  lastFocus = document.activeElement;        // بعد از بستن، فوکوس برگردد
  modal.classList.add("open");
  modal.setAttribute("aria-hidden", "false");
  document.body.classList.add("lock");       // قفل اسکرول صفحه
  const first = modal.querySelector("button");
  if (first) first.focus();
}
function closeModal(modal) {
  modal.classList.remove("open");
  modal.setAttribute("aria-hidden", "true");
  if (!document.querySelector(".modal.open")) document.body.classList.remove("lock");
  if (lastFocus) lastFocus.focus();
}

// Event Delegation: یک شنونده برای همه‌ی دکمه‌ها
document.addEventListener("click", (e) => {
  const opener = e.target.closest("[data-open]");
  if (opener) return openModal(opener.dataset.open);
  const closer = e.target.closest("[data-close]");
  if (closer) return closeModal(closer.closest(".modal"));
  if (e.target.classList.contains("modal")) closeModal(e.target);   // کلیک روی پس‌زمینه
});
document.addEventListener("keydown", (e) => {
  if (e.key === "Escape") document.querySelectorAll(".modal.open").forEach(closeModal);
});
