// کد وضعیت هوا (WMO) ← توضیح فارسی و ایموجی
const CODES = {
  0: ["آسمان صاف", "☀️"], 1: ["عمدتاً صاف", "🌤️"], 2: ["کمی ابری", "⛅"], 3: ["ابری", "☁️"],
  45: ["مه", "🌫️"], 48: ["مه یخ‌زده", "🌫️"], 51: ["نم‌نم باران", "🌦️"], 53: ["نم‌نم باران", "🌦️"], 55: ["نم‌نم باران", "🌦️"],
  61: ["باران ضعیف", "🌧️"], 63: ["باران", "🌧️"], 65: ["باران شدید", "🌧️"], 71: ["برف ضعیف", "🌨️"], 73: ["برف", "🌨️"], 75: ["برف شدید", "❄️"],
  80: ["رگبار", "🌧️"], 81: ["رگبار", "🌧️"], 82: ["رگبار شدید", "⛈️"], 95: ["رعدوبرق", "⛈️"], 96: ["رعدوبرق و تگرگ", "⛈️"], 99: ["رعدوبرق و تگرگ", "⛈️"],
};
const info = (code) => CODES[code] || ["نامشخص", "❔"];
const $ = (id) => document.getElementById(id);

function setState(text, error = false) { $("state").textContent = text; $("state").className = "state" + (error ? " err" : ""); }
async function getJSON(url) {
  const res = await fetch(url);
  if (!res.ok) throw new Error("خطای سرور " + res.status);
  return res.json();
}

async function loadWeather(name) {
  setState("در حال دریافت…");
  try {
    // درخواست ۱: تبدیل نام شهر به مختصات
    const geo = await getJSON("https://geocoding-api.open-meteo.com/v1/search?count=1&language=fa&name=" + encodeURIComponent(name));
    if (!geo.results || !geo.results.length) return setState("شهری با این نام پیدا نشد 😕", true);
    const { latitude, longitude, name: place, country } = geo.results[0];

    // درخواست ۲: آب‌وهوا با مختصات (وابسته به نتیجه‌ی اول)
    const w = await getJSON("https://api.open-meteo.com/v1/forecast?timezone=auto&forecast_days=5&latitude=" + latitude + "&longitude=" + longitude +
      "&current=temperature_2m,weather_code,wind_speed_10m,relative_humidity_2m&daily=weather_code,temperature_2m_max,temperature_2m_min");

    const [desc, emoji] = info(w.current.weather_code);
    $("place").textContent = place + (country ? "، " + country : "");
    $("em").textContent = emoji;
    $("temp").textContent = Math.round(w.current.temperature_2m) + "°";
    $("desc").textContent = desc;
    $("wind").textContent = "💨 " + Math.round(w.current.wind_speed_10m) + " km/h";
    $("hum").textContent = "💧 " + w.current.relative_humidity_2m + "٪";
    $("now").hidden = false;

    $("days").innerHTML = "";
    w.daily.time.forEach((date, i) => {
      const d = document.createElement("div");
      d.className = "day";
      d.innerHTML = "<small></small><div class='em'></div><b></b><small></small>";
      const [first, , , last] = d.children;
      first.textContent = new Date(date).toLocaleDateString("fa-IR", { weekday: "short" });
      d.children[1].textContent = info(w.daily.weather_code[i])[1];
      d.children[2].textContent = Math.round(w.daily.temperature_2m_max[i]) + "°";
      last.textContent = Math.round(w.daily.temperature_2m_min[i]) + "°";
      $("days").append(d);
    });
    setState("");
    try { localStorage.setItem("city", name); } catch (e) {}
  } catch (err) {
    setState("دریافت نشد: " + err.message, true);
  }
}

$("form").addEventListener("submit", (e) => { e.preventDefault(); const n = $("city").value.trim(); if (n) loadWeather(n); });
let last = "Tehran";
try { last = localStorage.getItem("city") || last; } catch (e) {}
$("city").value = last;
loadWeather(last);
